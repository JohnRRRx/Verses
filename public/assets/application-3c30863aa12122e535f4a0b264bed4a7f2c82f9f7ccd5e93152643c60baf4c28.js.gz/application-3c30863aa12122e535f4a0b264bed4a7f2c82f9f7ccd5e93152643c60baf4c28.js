import "@hotwired/turbo-rails"
import "./controllers"
import './spotify_search'

import jquery from "jquery"
window.$ = jquery

$(function(){
    alert('ok');
  });
