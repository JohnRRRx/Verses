import "@hotwired/turbo-rails"
import "./controllers"
import './spotify_search'
import "./flash.js";
