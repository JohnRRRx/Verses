import "@hotwired/turbo-rails"
import "./controllers"
import './spotify_search'

$(function(){
    setTimeout("$('.flash').fadeOut('slow')", 2000);
});
