$(document).ready(function() {
    setTimeout(function() {
      $('.flash').fadeOut('slow');
    }, 2000);
  });
