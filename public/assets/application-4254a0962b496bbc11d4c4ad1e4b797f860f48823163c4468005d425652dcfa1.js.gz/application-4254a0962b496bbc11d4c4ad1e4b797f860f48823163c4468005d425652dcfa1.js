import "@hotwired/turbo-rails"
import "./controllers"
import './spotify_search'
//= require jquery
//= require jquery_ujs;
