import { application } from "controllers/application"
eagerLoadControllersFrom("controllers", application);
